import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { Product } from '../../../models/product';
import { UserRole } from '../../../models/user';
import { ProductService } from '../../../services/product';
import { AuthService } from '../../../services/auth';

interface SelectedOptions {
  [productId: number]: {
    [optionName: string]: string;
  };
}

@Component({
  selector: 'app-product-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './product-page.html',
  styleUrls: ['./product-page.css']
})
export class ProductPage implements OnInit {
  products: Product[] = [];
  selectedOptions: SelectedOptions = {};
  role: UserRole | null = null;

  constructor(
    private productService: ProductService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.products = this.productService.getProducts();

    const user = this.authService.getCurrentUser();
    this.role = user?.role ?? null;
  }

  onOptionChange(product: Product, optionName: string, value: string): void {
    if (!this.selectedOptions[product.productId]) {
      this.selectedOptions[product.productId] = {};
    }
    this.selectedOptions[product.productId][optionName] = value;
  }

  getFinalPrice(product: Product): number {
    let price = product.basePrice;
    const optionsForProduct = this.selectedOptions[product.productId];

    if (!optionsForProduct) {
      return price;
    }

    for (const option of product.customOptions) {
      const selectedValue = optionsForProduct[option.name];
      if (
        selectedValue &&
        option.priceAdjustment &&
        option.priceAdjustment[selectedValue]
      ) {
        price += option.priceAdjustment[selectedValue];
      }
    }

    return price;
  }

  getSelectedSummary(product: Product): string {
    const optionsForProduct = this.selectedOptions[product.productId];
    if (!optionsForProduct) {
      return 'No customizations selected';
    }

    return product.customOptions
      .map(option => {
        const value = optionsForProduct[option.name] || '—';
        return `${option.name}: ${value}`;
      })
      .join(' | ');
  }

  // ----- Role-specific actions -----

  // CUSTOMER: place order / add to cart
  addToCart(product: Product): void {
    alert(`Customer: Added "${product.name}" to cart with selected options.`);
  }

  // VENDOR: manage listing
  editProduct(product: Product): void {
    alert(`Vendor: Edit listing for "${product.name}".`);
  }

  duplicateProduct(product: Product): void {
    alert(`Vendor: Duplicate listing for "${product.name}".`);
  }

  // ADMIN: oversee catalog / analytics
  viewProductInsights(product: Product): void {
    alert(`Admin: Viewing insights for "${product.name}".`);
  }

  deactivateProduct(product: Product): void {
    alert(`Admin: Deactivating "${product.name}".`);
  }

  onImageError(event: Event): void {
    const img = event.target as HTMLImageElement;
    img.src = 'https://via.placeholder.com/300x200?text=Preview';
  }
}
