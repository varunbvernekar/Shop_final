import { Component, signal } from '@angular/core';
import {
  RouterOutlet,
  RouterLink,
  RouterLinkActive,
  Router
} from '@angular/router';
import { NgIf } from '@angular/common';
import { CartService } from './services/cart';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, NgIf],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('ShopSphere');

  constructor(
    private router: Router,
    public cartService: CartService
  ) {}

  get cartCount(): number {
    return this.cartService.getItemCount();
  }

  goToCart(): void {
    // Show cart view inside ProductPage using query param
    this.router.navigate(['/products'], { queryParams: { view: 'cart' } });
  }
}
