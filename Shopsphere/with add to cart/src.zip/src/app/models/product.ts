export interface CustomOption {
  type: 'colour' | 'size' | 'material';
  name: string;
  values: string[];
  priceAdjustment?: { [value: string]: number }; // optional, for dynamic pricing
}

export interface Product {
  productId: number;
  name: string;
  basePrice: number;
  previewImage: string;
  customOptions: CustomOption[];

  // Extra fields used by customer catalog UI
  category?: string;
  description?: string;
}
