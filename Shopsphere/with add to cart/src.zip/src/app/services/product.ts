import { Injectable } from '@angular/core';
import { Product } from '../models/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  // Dummy in-memory product list:
  private products: Product[] = [
    {
      productId: 1,
      name: 'Handmade Silver Ring',
      basePrice: 1500,
      previewImage: 'assets/images/ring.jpg',
      category: 'Jewelry',
      description:
        'Minimal handcrafted silver ring with multiple sizes and finishes.',
      customOptions: [
        {
          type: 'colour',
          name: 'Colour',
          values: ['Silver', 'Rose Gold'],
          priceAdjustment: {
            Silver: 0,
            'Rose Gold': 200
          }
        },
        {
          type: 'size',
          name: 'Size',
          values: ['6', '7', '8'],
          priceAdjustment: {
            '6': 0,
            '7': 100,
            '8': 150
          }
        },
        {
          type: 'material',
          name: 'Material',
          values: ['Sterling Silver', '925 Silver'],
          priceAdjustment: {
            'Sterling Silver': 0,
            '925 Silver': 300
          }
        }
      ]
    },
    {
      productId: 2,
      name: 'Macrame Wall Hanging',
      basePrice: 2200,
      previewImage: 'assets/images/wall-hanging.jpg',
      category: 'Home Decor',
      description:
        'Boho macrame wall hanging made with premium cotton cords.',
      customOptions: [
        {
          type: 'colour',
          name: 'Colour',
          values: ['Beige', 'Olive Green'],
          priceAdjustment: {
            Beige: 0,
            'Olive Green': 250
          }
        },
        {
          type: 'size',
          name: 'Size',
          values: ['Small', 'Medium', 'Large'],
          priceAdjustment: {
            Small: 0,
            Medium: 200,
            Large: 400
          }
        },
        {
          type: 'material',
          name: 'Material',
          values: ['Cotton', 'Organic Cotton'],
          priceAdjustment: {
            Cotton: 0,
            'Organic Cotton': 300
          }
        }
      ]
    }
  ];

  constructor() {}

  getProducts(): Product[] {
    return this.products;
  }

  getProductById(id: number): Product | undefined {
    return this.products.find(p => p.productId === id);
  }
}
