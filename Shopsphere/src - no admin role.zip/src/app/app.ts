// src/app/app.ts
import { Component, signal } from '@angular/core';
import {
  RouterOutlet,
  RouterLink,
  RouterLinkActive,
  Router
} from '@angular/router';
import { NgIf } from '@angular/common';
import { CartService } from './services/cart';
import { AuthService } from './services/auth'; // 👈 NEW

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, NgIf],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('ShopSphere');

  constructor(
    private router: Router,
    public cartService: CartService,
    private authService: AuthService // 👈 NEW
  ) {}

  get cartCount(): number {
    return this.cartService.getItemCount();
  }

  // 👇 Show/hide logout button based on auth
  get isLoggedIn(): boolean {
    return this.authService.isLoggedIn();
  }

  goToCart(): void {
    this.router.navigate(['/products'], { queryParams: { view: 'cart' } });
  }

  // 👇 Logout + clear cart + redirect to login
  logout(): void {
    this.authService.logout();
    this.cartService.clear();      // optional but good practice
    this.router.navigate(['/login']);
  }
}
