import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Product } from '../../../models/product';
import { UserRole } from '../../../models/user';
import { ProductService } from '../../../services/product';
import { AuthService } from '../../../services/auth';
import { CartItem } from '../../../models/cart-item';
import { ProductCatalog } from './product-catalog/product-catalog';
import { ProductCustomizer } from './product-customizer/product-customizer';
import { Cart } from './cart/cart';

type CustomerView = 'catalog' | 'customizer' | 'cart';

@Component({
  selector: 'app-product-page',
  standalone: true,
  imports: [
    CommonModule,
    ProductCatalog,
    ProductCustomizer,
    Cart
  ],
  templateUrl: './product-page.html',
  styleUrls: ['./product-page.css']
})
export class ProductPage implements OnInit {
  products: Product[] = [];
  role: UserRole | null = null;

  // CUSTOMER flow state
  view: CustomerView = 'catalog';
  selectedProduct: Product | null = null;
  cartItems: CartItem[] = [];

  constructor(
    private productService: ProductService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.products = this.productService.getProducts();
    const user = this.authService.getCurrentUser();
    this.role = user?.role ?? null;
  }

  // ----- CUSTOMER flow -----
  handleSelectProduct(product: Product): void {
    if (this.role !== 'CUSTOMER') {
      return;
    }
    this.selectedProduct = product;
    this.view = 'customizer';
  }

  handleBackToCatalog(): void {
    this.selectedProduct = null;
    this.view = 'catalog';
  }

  handleAddToCart(event: {
    product: Product;
    customization: { color: string; size: string; material: string };
    price: number;
  }): void {
    const id = `item-${Date.now()}-${Math.random()
      .toString(36)
      .slice(2, 8)}`;

    const item: CartItem = {
      id,
      product: event.product,
      customization: event.customization,
      price: event.price,
      quantity: 1
    };

    this.cartItems.push(item);
    this.view = 'cart';
  }

  handleUpdateQuantity(update: { itemId: string; quantity: number }): void {
    this.cartItems = this.cartItems.map(item =>
      item.id === update.itemId ? { ...item, quantity: update.quantity } : item
    );
  }

  handleRemoveItem(itemId: string): void {
    this.cartItems = this.cartItems.filter(item => item.id !== itemId);
  }

  handleContinueShopping(): void {
    this.view = 'catalog';
  }

  // ----- Non-customer role actions -----
  editProduct(product: Product): void {
    alert(`Vendor: Edit listing for "${product.name}".`);
  }

  duplicateProduct(product: Product): void {
    alert(`Vendor: Duplicate listing for "${product.name}".`);
  }

  viewProductInsights(product: Product): void {
    alert(`Admin: Viewing insights for "${product.name}".`);
  }

  deactivateProduct(product: Product): void {
    alert(`Admin: Deactivating "${product.name}".`);
  }

  onImageError(event: Event): void {
    const img = event.target as HTMLImageElement;
    img.src = 'https://via.placeholder.com/300x200?text=Preview';
  }
}
